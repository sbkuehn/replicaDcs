# Description

This resource is used to wait for a disk to become available.
The disk to wait for is selected by specifying the _DiskId_ and optionally
_DiskIdType_.
The _DiskId_ value can be a _Disk Number_, _Unique Id_, _Guid_, _Location_,  _FriendlyName_ or _SerialNumber_.

**Important: The _Disk Number_ is not a reliable method of selecting a disk because
it has been shown to change between reboots in some environments.
It is recommended to use the _Unique Id_ if possible.**

The _Disk Number_, _Unique Id_, _Guid_, _Location_, _FriendlyName_ and _SerialNumber_ can be identified for a
disk by using the PowerShell command:

```powershell
Get-Disk | Select-Object -Property FriendlyName,DiskNumber,UniqueId,Guid,Location,SerialNumber
```

Note: The _Guid_ for a disk is only assigned once the partition table for the disk
has been created (e.g. the disk has been initialized). Therefore to use this method
of disk selection the disk must have been initialized by some other method.

## Known Issues

### Null Location

The _Location_ for a disk may be `null` for some types of disk,
e.g. file-based virtual disks. Physical disks or Virtual disks provided via a
hypervisor or other hardware virtualization platform should not be affected.
